import 'dart:io';

import 'package:share_plus/share_plus.dart';

class ShareContentService {
  
  Future<void> shareFile(File file) async {
    final XFile xFile = XFile(file.path);
    await Share.shareXFiles([xFile]);
  }
  
}