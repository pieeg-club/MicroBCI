import 'package:eeg_app/services/share_content_service/share_content_service.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

final shareContentServiceProvider = Provider<ShareContentService>((ref) {
  return ShareContentService();
});