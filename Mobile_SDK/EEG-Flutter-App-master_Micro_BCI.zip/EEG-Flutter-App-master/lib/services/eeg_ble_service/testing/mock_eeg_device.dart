import 'dart:async';
import 'dart:math';

import 'package:eeg_app/constants/data_processing_constants.dart';

class MockEEGDevice {
  late StreamController<List<int>> _streamController;

  Random random = Random();

  MockEEGDevice() {
    _streamController = StreamController<List<int>>.broadcast(
      onListen: _startStreaming,
      onCancel: _stopStreaming,
    );
  }

  void _startStreaming() {
    Timer.periodic(const Duration(milliseconds: 60), (Timer timer) {
      List<int> mockData = _generateMockEEGData();
      _streamController.add(mockData);
    });
  }

  void _stopStreaming() {
    // Do any necessary cleanup here
  }

  List<int> _generateMockEEGData() {
    List<int> mockData = [];
    for (int i = 0; i < bytesPerReceiveCycle; i++) {
      int previousData = mockData.isNotEmpty ? mockData.last : 0;
      int nextData = previousData + random.nextInt(3) - 1;
      if (nextData > 255) nextData = 255;
      if (nextData < 0) nextData = 0;
      mockData.add(nextData);
    }
    return mockData;
  }

  Stream<List<int>> get eegDataStream => _streamController.stream;
}
