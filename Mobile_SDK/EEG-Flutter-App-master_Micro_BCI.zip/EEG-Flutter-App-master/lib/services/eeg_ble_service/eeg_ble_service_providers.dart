import 'package:eeg_app/services/ble_service/ble_service_provider.dart';
import 'package:eeg_app/services/eeg_ble_service/eeg_ble_service.dart';
import 'package:eeg_app/services/eeg_ble_service/services/eeg_data_processing_service/eeg_data_processing_service_provider.dart';
import 'package:eeg_app/services/file_storage_service/models/marker_providers.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../file_storage_service/file_storage_service.dart';

final eegBleServiceProvider = Provider<EegBleService>((ref) {
  final bleService = ref.read(bleServiceProvider);
  final eegDataProcessingService = ref.read(eegDataProcessingServiceProvider);
  ProviderSubscription<Marker> subscription = ref.listen(markerProvider, (_, __) {});
  return EegBleService(
    bleService: bleService,
    eegDataProcessingService: eegDataProcessingService,
    markerProvider: subscription,
  );
});