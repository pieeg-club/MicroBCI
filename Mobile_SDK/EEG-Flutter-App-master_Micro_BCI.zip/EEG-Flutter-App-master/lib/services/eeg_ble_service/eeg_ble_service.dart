import 'dart:async';

import 'package:eeg_app/constants/bluetooth_constants.dart';
import 'package:eeg_app/services/ble_service/ble_service.dart';
import 'package:eeg_app/services/eeg_ble_service/services/eeg_data_processing_service/eeg_data_processing_service.dart';
import 'package:eeg_app/services/eeg_ble_service/testing/mock_eeg_device.dart';
import 'package:eeg_app/services/file_storage_service/models/marker.dart';
import 'package:flutter_blue_plus/flutter_blue_plus.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

class EegBleService {

  final BleService _bleService;
  final EegDataProcessingService _eegDataProcessingService;
  final ProviderSubscription<Marker> _markerSubscription;

  EegBleService({
    required BleService bleService,
    required EegDataProcessingService eegDataProcessingService,
    required ProviderSubscription<Marker> markerProvider,
  }) :
        _bleService = bleService,
        _eegDataProcessingService = eegDataProcessingService,
        _markerSubscription = markerProvider;



  Stream<List<ScanResult>> get eegDevices => _bleService.scanResults;



  Future<void> startScanForEegDevices() async {
    await _bleService.startScan();
  }



  Future<BluetoothDevice> connectToEegDevice(ScanResult scanResult) async{
    BluetoothDevice connectedDevice = await _bleService.connectToDevice(scanResult);
    await _bleService.requestRequiredMTU(connectedDevice, requiredMTU);
    return connectedDevice;
  }



  Future<BluetoothCharacteristic> getEegCharacteristic(BluetoothDevice eegDevice) async{
    BluetoothCharacteristic characteristic = await _bleService.findCharacteristicByUuid(
      connectedDevice: eegDevice,
      characteristicUUID: characteristicUUID,
    );
    return characteristic;
  }



  Future<void> startListeningAndProcessingCharacteristic(BluetoothCharacteristic eegCharacteristic) async {
    await _eegDataProcessingService.startDataProcessing();
    await _bleService.listenForDataFromCharacteristic(
      characteristic: eegCharacteristic,
      onDataReceived: _onEegDataReceived, // temporary solution
    );
  }



  void _onEegDataReceived(List<int> dataReceived) {
    Marker dataMarker = _markerSubscription.read();
    _eegDataProcessingService.onNewDataReceived(dataReceived: dataReceived, marker: dataMarker);
  }

  Future<void> receiveMockData() async {
    MockEEGDevice mockEEGDevice = MockEEGDevice();
    await _eegDataProcessingService.startDataProcessing();
    mockEEGDevice.eegDataStream.listen((List<int> dataReceived) {
      _onEegDataReceived(dataReceived);
    });
  }

}