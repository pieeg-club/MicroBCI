import 'package:eeg_app/models/processed_data_for_graph/processed_data_for_graph_providers.dart';
import 'package:eeg_app/services/eeg_ble_service/services/eeg_data_processing_service/eeg_data_processing_service.dart';
import 'package:eeg_app/services/file_storage_service/file_storage_service.dart';
import 'package:eeg_app/services/file_storage_service/file_storage_service_providers.dart';
import 'package:eeg_app/services/isolate_service/isolate_service.dart';
import 'package:eeg_app/services/isolate_service/isolate_service_providers.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

final eegDataProcessingServiceProvider = Provider<EegDataProcessingService>((ref) {
  final IsolateService isolateService = ref.read(isolateServiceProvider);
  final FileStorageService fileStorageService = ref.read(fileStorageServiceProvider);
  final processedDataForGraphModelNotifier = ref.read(processedDataForGraphModelNotifierProvider.notifier);
  return EegDataProcessingService(
    isolateService: isolateService,
    fileStorageService: fileStorageService,
    processedDataForGraphModelNotifier: processedDataForGraphModelNotifier,
  );
});