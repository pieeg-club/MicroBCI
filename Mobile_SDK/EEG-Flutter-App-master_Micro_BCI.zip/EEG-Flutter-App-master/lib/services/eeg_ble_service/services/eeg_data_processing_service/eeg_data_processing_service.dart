import 'package:eeg_app/constants/data_processing_constants.dart';
import 'package:eeg_app/models/processed_data_for_graph/processed_data_for_graph_model_notifier.dart';
import 'package:eeg_app/services/file_storage_service/file_storage_service.dart';
import 'package:eeg_app/services/isolate_service/isolate_service.dart';
import 'package:eeg_app/services/signal_processing_service/models/processed_data/processed_data.dart';
import 'package:fluttertoast/fluttertoast.dart';

class EegDataProcessingService {

  final IsolateService _isolateService;
  final FileStorageService _fileStorageService;

  final ProcessedDataForGraphModelNotifier _processedDataForGraphModelNotifier;

  EegDataProcessingService({
    required IsolateService isolateService,
    required FileStorageService fileStorageService,
    required ProcessedDataForGraphModelNotifier processedDataForGraphModelNotifier,
  }) :
    _isolateService = isolateService,
    _fileStorageService = fileStorageService,
    _processedDataForGraphModelNotifier = processedDataForGraphModelNotifier;


  Future<void> onNewDataReceived({
    required List<int> dataReceived,
    required Marker marker,
  }) async {
    if(dataReceived.length == bytesPerReceiveCycle){
      _isolateService.sendNewData(dataReceived);
      await _fileStorageService.saveData(
        data: dataReceived,
        marker: marker,
      );
    } else {
      Fluttertoast.showToast(msg: 'Data received is not of the correct length');
    }
  }



  Future<void> startDataProcessing() async {
    await _isolateService.startIsolate();
    _listenForProcessedData();
  }



  void _listenForProcessedData() {
    _isolateService.processedDataStream.listen((processedData) {
      _updateGraphsData(
        processedData: processedData,
      );
    });
  }




  void _updateGraphsData({
    required ProcessedData processedData,
  }) {
    try{
      _processedDataForGraphModelNotifier.setProcessedDataForGraph(processedData);
    } catch (e) {
      print('Error updating graphs data: $e');
      throw Exception('Error updating graphs data: $e');
    }
  }

}