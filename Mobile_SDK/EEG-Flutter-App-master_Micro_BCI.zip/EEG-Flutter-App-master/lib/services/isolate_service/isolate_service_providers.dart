import 'package:eeg_app/services/isolate_service/isolate_service.dart';
import 'package:eeg_app/services/signal_processing_service/signal_processing_service_providers.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

final isolateServiceProvider = Provider<IsolateService>((ref) {
  final signalProcessingService = ref.read(signalProcessingServiceProvider);
  return IsolateService(
    signalProcessingService: signalProcessingService,
  );
});