import 'dart:async';
import 'dart:isolate';

import 'package:eeg_app/constants/data_processing_constants.dart';
import 'package:eeg_app/models/data_buffer.dart';
import 'package:eeg_app/services/isolate_service/models/isolate_arguments/isolate_arguments.dart';
import 'package:eeg_app/services/signal_processing_service/models/processed_data/processed_data.dart';
import 'package:eeg_app/services/signal_processing_service/signal_processing_service.dart';

class IsolateService {

  final SignalProcessingService _signalProcessingService;

  IsolateService({
    required SignalProcessingService signalProcessingService,
  }) :
        _signalProcessingService = signalProcessingService;

  Isolate? _isolate;
  ReceivePort? _receivePort;
  SendPort? _sendPort;

  StreamController<ProcessedData> processedDataStreamController =
  StreamController<ProcessedData>.broadcast();


  Stream<ProcessedData> get processedDataStream =>
      processedDataStreamController.stream;



  Future<void> startIsolate() async {
    _receivePort = ReceivePort();
    IsolateArguments isolateArguments = IsolateArguments(
      sendPort: _receivePort!.sendPort,
      signalProcessingService: _signalProcessingService,
    );
    _isolate = await Isolate.spawn(_processDataInIsolate, isolateArguments);
    _receivePort!.listen((message) {
      if(message is SendPort) {
        _sendPort = message;
      }
      if(message is ProcessedData) {
        processedDataStreamController.add(message);
      }
    });
  }



  static void _processDataInIsolate(IsolateArguments isolateArguments) {
    SendPort sendPort = isolateArguments.sendPort;
    SignalProcessingService signalProcessingService =
        isolateArguments.signalProcessingService;
    ReceivePort receivePort = ReceivePort();
    sendPort.send(receivePort.sendPort);
    DataBuffer<int> dataBuffer = DataBuffer<int>(
      maxBufferLength: maxBufferLength,
    );
    int counter = 0;
    receivePort.listen((message) {
      if(message is List<int>) {
        dataBuffer.addData(message);
        counter++;
        if(counter % 5 == 0){
          counter = 0;
          ProcessedData processedData = signalProcessingService.processData(dataBuffer.data);
          sendPort.send(processedData);
        }
        // ProcessedData processedData = signalProcessingService.processData(dataBuffer.data);
        // sendPort.send(processedData);
      }
    });
  }



  void killIsolate() {
    _isolate?.kill();
  }



  void sendNewData(List<int> data) {
    _sendPort?.send(data);
  }
}