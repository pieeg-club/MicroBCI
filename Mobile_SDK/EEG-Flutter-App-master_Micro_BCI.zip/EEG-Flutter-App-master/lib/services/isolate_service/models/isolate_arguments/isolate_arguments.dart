import 'dart:isolate';

import 'package:eeg_app/services/signal_processing_service/signal_processing_service.dart';

class IsolateArguments{
  final SendPort sendPort;
  final SignalProcessingService signalProcessingService;

  IsolateArguments({
    required this.sendPort,
    required this.signalProcessingService,
  });
}