import 'package:eeg_app/services/file_storage_service/file_storage_service.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

class MarkerNotifier extends Notifier<Marker>{
  MarkerNotifier();

  @override
  Marker build() {
    return Marker(0);
  }

  void changeMarker(){
    try{
      if(state.markerType == 0){
        state = Marker(1);
      } else {
        state = Marker(0);
      }
    } catch(e){
      rethrow;
    }
  }

}