import 'package:eeg_app/services/file_storage_service/file_storage_service.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

final markerProvider = NotifierProvider<MarkerNotifier, Marker>(() {
  return MarkerNotifier();
});
