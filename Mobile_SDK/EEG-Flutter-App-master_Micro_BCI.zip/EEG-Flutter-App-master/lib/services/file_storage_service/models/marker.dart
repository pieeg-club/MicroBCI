class Marker {
  int markerType;

  Marker(this.markerType,);

  List<int> toBytes() {
    return [markerType];
  }

}
