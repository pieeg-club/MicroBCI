import 'dart:io';

export 'package:eeg_app/services/file_storage_service/models/marker.dart';
export 'package:eeg_app/services/file_storage_service/models/marker_notifier.dart';
export 'package:eeg_app/services/file_storage_service/models/marker_providers.dart';

import 'package:eeg_app/services/file_storage_service/models/marker.dart';
import 'package:path_provider/path_provider.dart';
import 'package:synchronized/synchronized.dart';

/// Provides file storage services, ensuring thread safety
/// through the use of locks and flushing operations to
/// maintain data integrity.
class FileStorageService {

  final Lock _lock = Lock();
  File? _file;


  /// Appends the provided data to the file.
  Future<void> saveData({
    required List<int> data,
    required Marker marker,
  }) async {
    try{
      await _lock.synchronized(() async {
        final file = await _getFile();
        List<int> markedData = _addMarkerToData(data: data, marker: marker);
        await file.writeAsString(markedData.toString(), mode: FileMode.append);
        // await file.writeAsBytes(data, mode: FileMode.append);
      });
    } catch(e) {
      rethrow;
    }
  }


  /// Retrieves a flushed file, ensuring all buffered data is written to disk.
  Future<File> getFlushedFile() async {
    try{
      return _lock.synchronized(() async {
        final file = await _getFile(flush: true);
        return file;
      });
    } catch(e) {
      rethrow;
    }
  }


  /// Deletes the file after ensuring all buffered data is written to disk.
  Future<void> deleteFileWithData() async{
    try{
      await _lock.synchronized(() async {
        final file = await _getFile(flush: true);
        if(!await file.exists()) return;
        await file.delete();
      });
    } catch(e) {
      rethrow;
    }
  }


  /// Helper method to get the file,
  /// with an option to flush buffered data to disk.
  Future<File> _getFile({bool flush = false}) async{
    try{
      if(_file == null){
        Directory appDirectory = await getApplicationDocumentsDirectory();
        // _file = File('${appDirectory!.path}/eeg_data.bin');
        _file = File('${appDirectory.path}/eeg_data.txt');
      }

      if (flush) {
        await _flushFile(_file!);
      }

      return _file!;
    } catch(e) {
      rethrow;
    }
  }


  /// Flushes buffered data to disk to ensure data integrity.
  Future<void> _flushFile(File file) async{
    try{
      RandomAccessFile randomAccessFile = await file.open();
      await randomAccessFile.flush();
      await randomAccessFile.close();
    } catch(e) {
      rethrow;
    }
  }


  /// Adds a marker to the data to indicate the start of a new data set.
  List<int> _addMarkerToData({
    required List<int> data,
    required Marker marker,
  }) {
    List<int> markerBytes = marker.toBytes();
    List<int> markedData = [...markerBytes, ...data];
    return markedData;
  }

}