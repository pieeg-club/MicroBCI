import 'package:eeg_app/models/bluetooth_characteristics/bluetooth_characteristics_providers.dart';
import 'package:eeg_app/models/bluetooth_services/bluetooth_servicees_providers.dart';
import 'package:eeg_app/services/ble_service/ble_service.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

final bleServiceProvider = Provider<BleService>((ref) {
  final bluetoothServicesModelNotifier = ref.read(bluetoothServicesModelNotifierProvider.notifier);
  final bluetoothCharacteristicsModelNotifier = ref.read(bluetoothCharacteristicsModelNotifierProvider.notifier);
  return BleService(
    bluetoothServicesModelNotifier: bluetoothServicesModelNotifier,
    bluetoothCharacteristicsModelNotifier: bluetoothCharacteristicsModelNotifier,
  );
});