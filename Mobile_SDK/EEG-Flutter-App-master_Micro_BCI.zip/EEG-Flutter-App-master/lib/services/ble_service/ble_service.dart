import 'dart:async';

import 'package:eeg_app/models/bluetooth_characteristics/bluetooth_characteristics_model_notifier.dart';
import 'package:eeg_app/models/bluetooth_services/bluetooth_servicees_model_notifier.dart';
import 'package:flutter_blue_plus/flutter_blue_plus.dart';
import 'package:fluttertoast/fluttertoast.dart';

class BleService {

  final BluetoothServicesModelNotifier _bluetoothServicesModelNotifier;
  final BluetoothCharacteristicsModelNotifier _bluetoothCharacteristicsModelNotifier;

  BleService({
    required BluetoothServicesModelNotifier bluetoothServicesModelNotifier,
    required BluetoothCharacteristicsModelNotifier bluetoothCharacteristicsModelNotifier,
  }) :
        _bluetoothServicesModelNotifier = bluetoothServicesModelNotifier,
        _bluetoothCharacteristicsModelNotifier = bluetoothCharacteristicsModelNotifier;


  StreamSubscription<List<int>>? _dataStreamSubscription;

  BluetoothDevice? _connectedDevice;


  Stream<List<ScanResult>> get scanResults => FlutterBluePlus.scanResults;

  BluetoothDevice? get connectedDevice => _connectedDevice;



  Future<void> startScan() async {
    await FlutterBluePlus.startScan(timeout: const Duration(seconds: 5));
  }



  Future<BluetoothDevice> connectToDevice(ScanResult scanResult) async{
    try{
      await scanResult.device.connect(timeout: const Duration(seconds: 5));
      _connectedDevice = scanResult.device;
      if(_connectedDevice == null){
        throw Exception('Error connecting to device: device is null');
      }
      Fluttertoast.showToast(msg: "Connected");
      return _connectedDevice!;
    } catch (e) {
      Fluttertoast.showToast(msg: e.toString());
      print('Error connecting to device: $e');
      throw Exception('Error connecting to device: $e');
    }
  }


  Future<void> disconnect() async{
    try{
      if(_dataStreamSubscription != null && _connectedDevice != null){
        _dataStreamSubscription?.cancel();
        await _connectedDevice?.disconnect();
        Fluttertoast.showToast(msg: 'Disconnected');
      }
      else {
        Fluttertoast.showToast(msg: 'No device connected');
      }
    } catch (e){
      Fluttertoast.showToast(msg: e.toString());
    }
  }



  Future<void> requestRequiredMTU(BluetoothDevice connectedDevice, int requiredMtu) async{
    try{
      await connectedDevice.requestMtu(requiredMtu);
      Fluttertoast.showToast(msg: 'mtu is set to $requiredMtu');
    } catch (e){
      Fluttertoast.showToast(msg: e.toString());
    }
  }



  Future<void> listenForDataFromCharacteristic({
    required BluetoothCharacteristic characteristic,
    required void Function(List<int>) onDataReceived,
  }) async {
    _dataStreamSubscription = characteristic.onValueReceived.listen((List<int> dataReceived) {
      onDataReceived(dataReceived);
    });
    await characteristic.setNotifyValue(true);
  }



  Future<BluetoothCharacteristic> findCharacteristicByUuid({
    required String characteristicUUID,
    required BluetoothDevice connectedDevice,
    String? serviceUUID,
  }) async{
    List<BluetoothService> services = await connectedDevice.discoverServices();
    if (serviceUUID != null) {
      services = services.where((service) => service.uuid.toString() == serviceUUID).toList();
      if (services.isEmpty) {
        print('Error getting characteristic: no service with uuid $serviceUUID');
        throw Exception('Error getting characteristic: no service with uuid $serviceUUID');
      }
    }
    for (BluetoothService service in services) {
      _bluetoothServicesModelNotifier.addBluetoothService(service);
      var characteristics = service.characteristics;
      for (BluetoothCharacteristic characteristic in characteristics){
        _bluetoothCharacteristicsModelNotifier.addBluetoothCharacteristic(characteristic);
        if (characteristic.uuid.toString() == characteristicUUID) {
          return characteristic;
        }
      }
    }
    throw Exception('Error getting characteristic: no characteristic with uuid $characteristicUUID');
  }

}