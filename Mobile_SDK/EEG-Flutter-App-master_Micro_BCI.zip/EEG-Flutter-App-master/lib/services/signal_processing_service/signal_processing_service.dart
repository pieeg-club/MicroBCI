import 'package:eeg_app/services/signal_processing_service/models/processed_data/processed_data.dart';
import 'package:eeg_app/services/signal_processing_service/models/wavesPowerRatio.dart';
import 'package:eeg_app/services/signal_processing_service/services/band_pass_filter/band_pass_filter_service.dart';
import 'package:eeg_app/services/signal_processing_service/services/device_data_processor/device_data_processor_service.dart';
import 'package:eeg_app/services/signal_processing_service/services/fast_fourier_transform/fast_fourier_transform_service.dart';
import 'package:eeg_app/services/signal_processing_service/services/fast_fourier_transform/models/fast_fourier_transform_restult/fast_fourier_transform_result.dart';
import 'package:eeg_app/services/signal_processing_service/models/processed_channel_data/processed_channel_data.dart';

class SignalProcessingService {

  final DeviceDataProcessorService _deviceDataProcessorService;
  final BandPassFilterService _bandPassFilterService;
  final FastFourierTransformService _fastFourierTransformService;
  final int _numberOfChannels;
  final int _bytesPerSample;

  SignalProcessingService({
    required DeviceDataProcessorService deviceDataProcessorService,
    required BandPassFilterService bandPassFilterService,
    required FastFourierTransformService fastFourierTransformService,
    required int numberOfChannels,
    required int bytesPerSample,
  }) :
    _deviceDataProcessorService = deviceDataProcessorService,
    _bandPassFilterService = bandPassFilterService,
    _fastFourierTransformService = fastFourierTransformService,
    _numberOfChannels = numberOfChannels,
        _bytesPerSample = bytesPerSample;



  ProcessedData processData(List<int> data) {
    ProcessedData processedData = ProcessedData(
      processedData: [],
    );
    List<List<int>> channelData = _splitIntoChannels(data);

    for (int channel = 0; channel < _numberOfChannels; channel++) {
      ProcessedChannelData processedChannelData = _processChannelData(
        channel: channel,
        data: channelData[channel],
      );
      processedData.addProcessedChannelData(processedChannelData);
    }

    WavesPowerRatio wavesPowerRatio = _calculateWavesPowerRatio(
      processedData: processedData,
    );

    processedData.setWavesPowerRatio(wavesPowerRatio);

    return processedData;
  }



  List<List<int>> _splitIntoChannels(List<int> data) {
    List<List<int>> channelData = List.generate(
      _numberOfChannels,
          (_) => [],
      growable: false,
    );

    for (int sample = 0; sample < (data.length / _bytesPerSample); sample++) {
      int channel = sample % _numberOfChannels;
      channelData[channel].addAll(data.sublist(sample * _bytesPerSample, (sample + 1) * _bytesPerSample));
    }

    return channelData;
  }



  ProcessedChannelData _processChannelData({
    required int channel,
    required List<int> data,
  }) {

    List<double> eegReadings = _deviceDataProcessorService
        .processRawDeviceData(data);

    final List<double> bandPassFilterResults =
    _bandPassFilterService.applyBandPassFilter(eegReadings);

    final List<FFTDataPoint> fastFourierTransformResult =
    _fastFourierTransformService.applyFastFourierTransform(bandPassFilterResults);

    return ProcessedChannelData(
      channel: channel,
      eegReadings: eegReadings,
      bandPassFilterResults: bandPassFilterResults,
      fastFourierTransformResult: fastFourierTransformResult,
    );
  }


  WavesPowerRatio _calculateWavesPowerRatio({required ProcessedData processedData,}){
    double averageAlphaWavePower = _calculateAverageWavePower(
      processedData: processedData,
      leftCutOffFreq: 8,
      rightCutOffFreq: 12,
    );

    double averageBetaWavePower = _calculateAverageWavePower(
      processedData: processedData,
      leftCutOffFreq: 12,
      rightCutOffFreq: 30,
    );

    double averageThetaWavePower = _calculateAverageWavePower(
      processedData: processedData,
      leftCutOffFreq: 4,
      rightCutOffFreq: 8,
    );

    double alphaBetaRatio = averageAlphaWavePower == 0 && averageBetaWavePower == 0
        ? 0
        : averageAlphaWavePower / averageBetaWavePower;

    double thetaBetaRatio = averageThetaWavePower == 0 && averageBetaWavePower == 0
        ? 0
        : averageThetaWavePower / averageBetaWavePower;

    WavesPowerRatio wavesPowerRatio =  WavesPowerRatio(
      alphaBetaRatio: alphaBetaRatio,
      thetaBetaRatio: thetaBetaRatio,
    );

    return wavesPowerRatio;
  }


  double _calculateAverageWavePower({
    required ProcessedData processedData,
    required double leftCutOffFreq,
    required double rightCutOffFreq,
  }) {
    double averageWavePower = 0;
    for (int channel = 0; channel < _numberOfChannels; channel++) {
      List<FFTDataPoint> fftDataPoints = processedData
          .processedData[channel].fastFourierTransformResult;
      averageWavePower += _fastFourierTransformService
          .calculatePowerPerUnitFrequency(
          fftDataPoints: fftDataPoints,
          leftCutOffFreq: leftCutOffFreq,
          rightCutOffFreq: rightCutOffFreq,
      );
    }
    return averageWavePower / _numberOfChannels;
  }


}