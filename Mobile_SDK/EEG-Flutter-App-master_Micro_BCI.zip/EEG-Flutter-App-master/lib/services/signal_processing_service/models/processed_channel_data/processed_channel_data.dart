import 'package:eeg_app/services/signal_processing_service/services/fast_fourier_transform/models/fast_fourier_transform_restult/fast_fourier_transform_result.dart';

class ProcessedChannelData {
  final int channel;
  final List<double> eegReadings;
  final List<double> bandPassFilterResults;
  final List<FFTDataPoint> fastFourierTransformResult;

  ProcessedChannelData ({
    required this.channel,
    required this.eegReadings,
    required this.bandPassFilterResults,
    required this.fastFourierTransformResult,
  });
}