import 'package:eeg_app/services/signal_processing_service/models/processed_channel_data/processed_channel_data.dart';
import 'package:eeg_app/services/signal_processing_service/models/wavesPowerRatio.dart';

class ProcessedData{
  // each index represents a channel
  final List<ProcessedChannelData> _processedData;
  WavesPowerRatio _wavesPowerRatio;

  ProcessedData({
    required List<ProcessedChannelData> processedData,
  }) : _processedData = processedData,
        _wavesPowerRatio = WavesPowerRatio.empty();

  List<ProcessedChannelData> get processedData => _processedData;

  WavesPowerRatio get wavesPowerRatio => _wavesPowerRatio;

  factory ProcessedData.empty(int numberOfChannels) {
    final List<ProcessedChannelData> processedData = List.generate(
      numberOfChannels,
          (channel) => ProcessedChannelData(
        channel: channel,
        eegReadings: [],
        bandPassFilterResults: [],
        fastFourierTransformResult: [],
      ),
    );
    return ProcessedData(processedData: processedData);
  }

  void addProcessedChannelData(ProcessedChannelData processedChannelData) {
    _processedData.add(processedChannelData);
  }

  void setWavesPowerRatio(WavesPowerRatio wavesPowerRatio) {
    _wavesPowerRatio = wavesPowerRatio;
  }
}