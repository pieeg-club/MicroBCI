class WavesPowerRatio {
  final double alphaBetaRatio;
  final double thetaBetaRatio;

  WavesPowerRatio({
    required this.alphaBetaRatio,
    required this.thetaBetaRatio,
  });

  factory WavesPowerRatio.empty() {
    return WavesPowerRatio(
      alphaBetaRatio: 0,
      thetaBetaRatio: 0,
    );
  }
}