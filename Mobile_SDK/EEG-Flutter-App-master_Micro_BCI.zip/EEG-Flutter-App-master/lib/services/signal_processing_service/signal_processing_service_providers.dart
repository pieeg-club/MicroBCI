import 'package:eeg_app/constants/data_processing_constants.dart';
import 'package:eeg_app/services/signal_processing_service/services/band_pass_filter/band_pass_filter_providers.dart';
import 'package:eeg_app/services/signal_processing_service/services/device_data_processor/device_data_processor_providers.dart';
import 'package:eeg_app/services/signal_processing_service/services/fast_fourier_transform/fast_fourier_transform_providers.dart';
import 'package:eeg_app/services/signal_processing_service/signal_processing_service.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

final signalProcessingServiceProvider = Provider<SignalProcessingService>((ref) {
  final deviceDataProcessorService = ref.read(deviceDataProcessorServiceProvider);
  final bandPassFilterService = ref.read(bandPassFilterServiceProvider);
  final fastFourierTransformService = ref.read(fastFourierTransformServiceProvider);
  return SignalProcessingService(
    deviceDataProcessorService: deviceDataProcessorService,
    bandPassFilterService: bandPassFilterService,
    fastFourierTransformService: fastFourierTransformService,
    numberOfChannels: numberOfChannels,
    bytesPerSample: bytesPerSample,
  );
});