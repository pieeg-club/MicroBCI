import 'package:eeg_app/services/signal_processing_service/services/device_data_processor/device_data_processor_service.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

final deviceDataProcessorServiceProvider = Provider<DeviceDataProcessorService>((ref) {
  return DeviceDataProcessorService();
});