class VoltageData {
  final List<double> firstRawData;
  final List<double> secondRawData;
  final List<double> thirdRawData;
  final List<double> fourthRawData;

  VoltageData({
    required this.firstRawData,
    required this.secondRawData,
    required this.thirdRawData,
    required this.fourthRawData,
  });


}