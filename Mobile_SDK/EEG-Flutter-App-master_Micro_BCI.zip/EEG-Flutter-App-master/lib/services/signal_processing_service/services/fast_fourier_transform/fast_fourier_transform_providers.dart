import 'package:eeg_app/services/signal_processing_service/services/fast_fourier_transform/fast_fourier_transform_service.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

final fastFourierTransformServiceProvider =
Provider<FastFourierTransformService>((ref) => FastFourierTransformService());