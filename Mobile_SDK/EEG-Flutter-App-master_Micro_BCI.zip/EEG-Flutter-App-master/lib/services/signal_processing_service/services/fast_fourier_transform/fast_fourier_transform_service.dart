import 'dart:math';
import 'dart:typed_data';

import 'package:eeg_app/constants/data_processing_constants.dart';
import 'package:eeg_app/services/signal_processing_service/services/fast_fourier_transform/models/fast_fourier_transform_restult/fast_fourier_transform_result.dart';
import 'package:fftea/fftea.dart';

class FastFourierTransformService{

  double calculatePowerPerUnitFrequency({
    required List<FFTDataPoint> fftDataPoints,
    required double leftCutOffFreq,
    required double rightCutOffFreq,
  }){
    double totalPower = 0;
    int numberOfDataPointsWithinRange = 0;
    for (FFTDataPoint fftDataPoint in fftDataPoints) {
      if (fftDataPoint.frequency >= leftCutOffFreq && fftDataPoint.frequency <= rightCutOffFreq) {
        totalPower += pow(fftDataPoint.amplitude, 2);
        numberOfDataPointsWithinRange++;
      }
    }
    if (numberOfDataPointsWithinRange == 0) return 0;
    double powerPerUnitFrequency = totalPower / numberOfDataPointsWithinRange;
    return powerPerUnitFrequency;
  }



  List<FFTDataPoint> applyFastFourierTransform(List<double> data){

    // If there is no data, return an empty list
    if (data.isEmpty) return [];

    // Apply FFT and normalize
    Float64x2List fourierTransform = FFT(data.length).realFft(data);
    int N = fourierTransform.length;
    Float64x2 complexLength = Float64x2(N.toDouble(), N.toDouble());
    fourierTransform = Float64x2List.fromList(fourierTransform.map((x) => x / complexLength).toList());

    // Take the first half of the FFT result
    fourierTransform = fourierTransform.sublist(0, (N / 2).floor());

    // Create the results with amplitude and frequency
    List<FFTDataPoint> fastFourierTransformResults = _createResults(fourierTransform);

    return fastFourierTransformResults;

  }



  List<FFTDataPoint> _createResults(Float64x2List fourierTransform){

    int fftResultLength = fourierTransform.length;
    double timePeriod = fftResultLength / samplingFrequency;

    List<FFTDataPoint> fastFourierTransformResults = List<FFTDataPoint>.generate(
        fftResultLength,
            (i) => FFTDataPoint(
            amplitude: _getMagnitude(
                fourierTransform[i].x,
                fourierTransform[i].y
            ),
            frequency: i / timePeriod,
        )
    );
    return fastFourierTransformResults;
  }

  double _getMagnitude(double realPart, double imaginaryPart) {
    return sqrt(realPart * realPart + imaginaryPart * imaginaryPart);
  }

}