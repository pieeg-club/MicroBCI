class FFTDataPoint{
  final double amplitude;
  final double frequency;

  FFTDataPoint({
    required this.amplitude,
    required this.frequency,
  });
}