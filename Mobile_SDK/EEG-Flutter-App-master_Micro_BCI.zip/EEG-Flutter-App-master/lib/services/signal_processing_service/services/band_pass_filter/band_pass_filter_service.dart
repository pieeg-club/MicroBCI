import 'package:eeg_app/constants/data_processing_constants.dart';
import 'package:iirjdart/butterworth.dart';

class BandPassFilterService {

  final Butterworth _butterworth;

  BandPassFilterService()
      : _butterworth = Butterworth()
  {
    _initializeBandPassFilter();
  }

  void _initializeBandPassFilter() {
    double centerFreq = (rightCutOffFreq + leftCutOffFreq) / 2;
    double widthInFreq = rightCutOffFreq - leftCutOffFreq;
    _butterworth.bandPass(order, samplingFrequency, centerFreq, widthInFreq);
  }

  List<double> applyBandPassFilter(List<double> data) {
    if (data.length < bandPassMinProcessedLength) return [];

    List<double> filteredData = [];
    for (double sample in data) {
      filteredData.add(_butterworth.filter(sample));
    }
    return filteredData.length < bandPassWarmUpLength ? [] : filteredData.sublist(bandPassWarmUpLength);
  }

}