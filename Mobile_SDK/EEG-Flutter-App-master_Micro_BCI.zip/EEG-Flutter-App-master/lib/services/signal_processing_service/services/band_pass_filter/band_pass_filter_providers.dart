import 'package:eeg_app/services/signal_processing_service/services/band_pass_filter/band_pass_filter_service.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

final bandPassFilterServiceProvider = Provider<BandPassFilterService>((ref) {
  return BandPassFilterService();
});