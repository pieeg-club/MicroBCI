import 'package:eeg_app/models/processed_data_for_graph/processed_data_for_graph_model.dart';
import 'package:eeg_app/services/signal_processing_service/models/processed_channel_data/processed_channel_data.dart';
import 'package:eeg_app/services/signal_processing_service/models/processed_data/processed_data.dart';
import 'package:eeg_app/services/signal_processing_service/models/wavesPowerRatio.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

class ProcessedDataForGraphModelNotifier extends StateNotifier<ProcessedDataForGraphModel>{
  ProcessedDataForGraphModelNotifier({required ProcessedDataForGraphModel initialState}) : super(initialState);

  void setProcessedDataForGraph(ProcessedData processedData) {
    List<WavesPowerRatio> listWavesPowerRatio = state.listWavesPowerRatio.toList();
    listWavesPowerRatio.add(processedData.wavesPowerRatio);
    state = ProcessedDataForGraphModel(
      processedDataForGraph: processedData,
      listWavesPowerRatio: listWavesPowerRatio,
    );
  }

}