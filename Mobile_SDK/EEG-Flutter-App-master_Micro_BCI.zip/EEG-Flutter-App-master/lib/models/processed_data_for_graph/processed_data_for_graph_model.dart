import 'package:eeg_app/services/signal_processing_service/models/processed_data/processed_data.dart';
import 'package:eeg_app/services/signal_processing_service/models/wavesPowerRatio.dart';

class ProcessedDataForGraphModel{
  final ProcessedData processedDataForGraph;
  final List<WavesPowerRatio> listWavesPowerRatio;

  ProcessedDataForGraphModel({
    required this.processedDataForGraph,
    this.listWavesPowerRatio = const [],
  });
}