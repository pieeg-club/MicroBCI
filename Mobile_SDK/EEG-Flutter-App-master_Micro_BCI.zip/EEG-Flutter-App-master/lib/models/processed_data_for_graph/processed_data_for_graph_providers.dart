import 'package:eeg_app/constants/data_processing_constants.dart';
import 'package:eeg_app/models/processed_data_for_graph/processed_data_for_graph_model.dart';
import 'package:eeg_app/models/processed_data_for_graph/processed_data_for_graph_model_notifier.dart';
import 'package:eeg_app/services/signal_processing_service/models/processed_data/processed_data.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

final processedDataForGraphModelNotifierProvider = StateNotifierProvider<ProcessedDataForGraphModelNotifier, ProcessedDataForGraphModel>(
(ref) {
  ProcessedData processedData = ProcessedData.empty(numberOfChannels);
  final ProcessedDataForGraphModel processedDataForGraphModel =
  ProcessedDataForGraphModel(processedDataForGraph: processedData);
  return ProcessedDataForGraphModelNotifier(
    initialState: processedDataForGraphModel,
  );
});