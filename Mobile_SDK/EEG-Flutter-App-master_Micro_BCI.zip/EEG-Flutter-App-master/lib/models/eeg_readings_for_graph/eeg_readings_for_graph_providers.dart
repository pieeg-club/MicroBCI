import 'package:eeg_app/models/eeg_readings_for_graph/eeg_readings_for_graph_model.dart';
import 'package:eeg_app/models/eeg_readings_for_graph/eeg_readings_for_graph_model_notifier.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

final eegReadingsForGraphModelNotifierProvider = StateNotifierProvider<EegReadingsForGraphModelNotifier, EegReadingsForGraphModel>((ref) {
  final dataForGraphModel = EegReadingsForGraphModel(dataForGraph: []);
  return EegReadingsForGraphModelNotifier(initialState: dataForGraphModel);
});