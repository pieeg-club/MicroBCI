class EegReadingsForGraphModel {
  final List<double> dataForGraph;

  EegReadingsForGraphModel({required this.dataForGraph,});
}