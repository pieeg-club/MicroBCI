import 'package:eeg_app/models/eeg_readings_for_graph/eeg_readings_for_graph_model.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

class EegReadingsForGraphModelNotifier extends StateNotifier<EegReadingsForGraphModel> {

  EegReadingsForGraphModelNotifier({
    required EegReadingsForGraphModel initialState,
  }) : super(initialState);

  void addDataForGraphFromList(List<double> newDataForGraph) {
    state = EegReadingsForGraphModel(
      dataForGraph: [...state.dataForGraph, ...newDataForGraph],
    );
  }

  void setDataForGraph(List<double> newDataForGraph) {
    state = EegReadingsForGraphModel(
      dataForGraph: newDataForGraph,
    );
  }

}