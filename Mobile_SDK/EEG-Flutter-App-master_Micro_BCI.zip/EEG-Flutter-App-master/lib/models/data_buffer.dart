import 'dart:collection';

class DataBuffer<T> {
  final Queue<T> _buffer = Queue<T>();
  final int maxBufferLength;

  DataBuffer({
    required this.maxBufferLength,
  });

  List<T> get data => _buffer.toList();

  void addData(List<T> data){
    for (T d in data) {
      _buffer.add(d);
    }
    while (_buffer.length > maxBufferLength) {
      _buffer.removeFirst();
    }
  }
}