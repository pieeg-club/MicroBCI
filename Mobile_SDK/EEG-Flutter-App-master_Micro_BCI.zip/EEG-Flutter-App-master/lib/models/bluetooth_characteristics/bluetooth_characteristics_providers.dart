import 'package:eeg_app/models/bluetooth_characteristics/bluetooth_characteristics_model.dart';
import 'package:eeg_app/models/bluetooth_characteristics/bluetooth_characteristics_model_notifier.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

final bluetoothCharacteristicsModelNotifierProvider = StateNotifierProvider<BluetoothCharacteristicsModelNotifier, BluetoothCharacteristicsModel>(
  (ref) => BluetoothCharacteristicsModelNotifier(
    initialState: BluetoothCharacteristicsModel(
      bluetoothCharacteristics: [],
    ),
  ),
);