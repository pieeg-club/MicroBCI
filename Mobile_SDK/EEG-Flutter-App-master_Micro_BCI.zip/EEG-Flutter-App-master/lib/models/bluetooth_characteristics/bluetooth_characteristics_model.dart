import 'package:flutter_blue_plus/flutter_blue_plus.dart';

class BluetoothCharacteristicsModel {
  List<BluetoothCharacteristic> bluetoothCharacteristics;

  BluetoothCharacteristicsModel({
    required this.bluetoothCharacteristics,
  });
}