import 'package:eeg_app/models/bluetooth_characteristics/bluetooth_characteristics_model.dart';
import 'package:flutter_blue_plus/flutter_blue_plus.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

class BluetoothCharacteristicsModelNotifier extends StateNotifier<BluetoothCharacteristicsModel>{
  BluetoothCharacteristicsModelNotifier({
    required BluetoothCharacteristicsModel initialState,
  }) : super(initialState);

  void addBluetoothCharacteristic(BluetoothCharacteristic bluetoothCharacteristic) {
    state = BluetoothCharacteristicsModel(
      bluetoothCharacteristics: [...state.bluetoothCharacteristics, bluetoothCharacteristic],
    );
  }
}