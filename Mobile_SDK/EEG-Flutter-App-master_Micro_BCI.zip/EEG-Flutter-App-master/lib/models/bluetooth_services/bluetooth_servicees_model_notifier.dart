import 'package:eeg_app/models/bluetooth_services/bluetooth_servicees_model.dart';
import 'package:flutter_blue_plus/flutter_blue_plus.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

class BluetoothServicesModelNotifier extends StateNotifier<BluetoothServicesModel>{

  BluetoothServicesModelNotifier({required BluetoothServicesModel initialState})
      : super(initialState);

  void addBluetoothService(BluetoothService bluetoothService) {
    state = BluetoothServicesModel(
      bluetoothServices: [
        ...state.bluetoothServices,
        bluetoothService
      ]
    );
  }

}