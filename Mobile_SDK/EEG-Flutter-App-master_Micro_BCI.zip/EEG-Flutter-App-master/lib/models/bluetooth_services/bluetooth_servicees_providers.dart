import 'package:eeg_app/models/bluetooth_services/bluetooth_servicees_model.dart';
import 'package:eeg_app/models/bluetooth_services/bluetooth_servicees_model_notifier.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

final bluetoothServicesModelNotifierProvider = StateNotifierProvider<BluetoothServicesModelNotifier, BluetoothServicesModel>(
  (ref) => BluetoothServicesModelNotifier(
    initialState: BluetoothServicesModel(
      bluetoothServices: []
    )
  )
);