import 'package:eeg_app/services/signal_processing_service/services/fast_fourier_transform/models/fast_fourier_transform_restult/fast_fourier_transform_result.dart';

class FFTResultsForGraphModel {
  final List<FFTDataPoint> fastFourierTransformResults;

  FFTResultsForGraphModel({required this.fastFourierTransformResults});
}