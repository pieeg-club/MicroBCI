import 'package:eeg_app/models/fft_results_for_graph/fft_results_for_graph_model.dart';
import 'package:eeg_app/models/fft_results_for_graph/fft_results_for_graph_model_notifier.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

final fftResultsForGraphModelNotifierProvider = StateNotifierProvider<FFTResultsForGraphModelNotifier, FFTResultsForGraphModel>((ref) {
  final fftResultsForGraphModel = FFTResultsForGraphModel(
    fastFourierTransformResults: [],
  );
  return FFTResultsForGraphModelNotifier(initialState: fftResultsForGraphModel,);
});