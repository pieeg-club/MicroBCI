import 'package:eeg_app/models/fft_results_for_graph/fft_results_for_graph_model.dart';
import 'package:eeg_app/services/signal_processing_service/services/fast_fourier_transform/models/fast_fourier_transform_restult/fast_fourier_transform_result.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

class FFTResultsForGraphModelNotifier extends StateNotifier<FFTResultsForGraphModel>{

  FFTResultsForGraphModelNotifier({
    required FFTResultsForGraphModel initialState,
  }) : super(initialState);

  void addFFTResultsForGraph(List<FFTDataPoint> fastFourierTransformResults) {
    state = FFTResultsForGraphModel(
      fastFourierTransformResults: [...state.fastFourierTransformResults, ...fastFourierTransformResults],
    );
  }

  void setFFTResultsForGraph(List<FFTDataPoint> fastFourierTransformResults) {
    state = FFTResultsForGraphModel(
      fastFourierTransformResults: fastFourierTransformResults,
    );
  }
}