import 'package:eeg_app/models/band_pass_results_for_graph/band_pass_results_for_graph_model.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

class BandPassResultsForGraphModelNotifier extends StateNotifier<BandPassResultsForGraphModel> {

  BandPassResultsForGraphModelNotifier({
    required BandPassResultsForGraphModel initialState,
  }) : super(initialState);

  void addBandPassResultsForGraphFromList(List<double> bandPassResults){
    state = BandPassResultsForGraphModel(
      bandPassResults: [...state.bandPassResults, ...bandPassResults],
    );
  }

  void setBandPassResultsForGraph(List<double> bandPassResults){
    state = BandPassResultsForGraphModel(
      bandPassResults: bandPassResults,
    );
  }

}