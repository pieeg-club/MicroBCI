import 'package:eeg_app/models/band_pass_results_for_graph/band_pass_results_for_graph_model.dart';
import 'package:eeg_app/models/band_pass_results_for_graph/band_pass_results_for_graph_model_notifier.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

final bandPassResultsForGraphModelNotifierProvider = StateNotifierProvider<BandPassResultsForGraphModelNotifier, BandPassResultsForGraphModel>((ref) {
  final bandPassResultsForGraphModel = BandPassResultsForGraphModel(
    bandPassResults: [],
  );
  return BandPassResultsForGraphModelNotifier(
    initialState: bandPassResultsForGraphModel,
  );
});