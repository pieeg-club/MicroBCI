class BandPassResultsForGraphModel {

  final List<double> bandPassResults;

  BandPassResultsForGraphModel({
    required this.bandPassResults,
  });
}