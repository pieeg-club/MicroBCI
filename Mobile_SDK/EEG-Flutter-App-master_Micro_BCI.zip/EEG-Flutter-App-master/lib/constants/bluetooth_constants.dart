const int requiredMTU = 200;
const String characteristicUUID = "0000fe42-8e22-4541-9d4c-21edae82ed19";