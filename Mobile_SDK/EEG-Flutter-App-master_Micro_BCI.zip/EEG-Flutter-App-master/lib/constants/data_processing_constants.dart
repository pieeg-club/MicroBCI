import 'dart:math';

const double samplingFrequency = 250;


// device data processor constants

const int numberOfChannels = 4;
const int bytesPerChannel = bytesPerReceiveCycle ~/ numberOfChannels;
const int bytesPerSample = 3;
const int bytesPerReceiveCycle = 120;
const int samplesPerReceiveCycle = bytesPerReceiveCycle ~/ bytesPerSample;
const int numberOfReceiveCycleToProcess = 30 * numberOfChannels;
const int maxBufferLength = bandPassWarmUpLength * bytesPerSample * numberOfChannels +
    bytesPerReceiveCycle * numberOfReceiveCycleToProcess;
// Calculate the maximum representable number with 'bytesPerSample' bytes.
// This is done using 2^(bytesPerSample * 8) - 1 to consider all the bits in the bytes.
final int maxNumberWithBytesPerSample = pow(2, bytesPerSample * 8).toInt() - 1;
const double maxVoltage = 4.5;


// band pass filter constants

const double leftCutOffFreq = 0.5;
const double rightCutOffFreq = 30.0;
const int bandPassWarmUpLength = bytesPerReceiveCycle * 15;
const int bandPassMinProcessedLength = 500;
const int order = 5;