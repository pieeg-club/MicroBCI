import 'package:eeg_app/models/bluetooth_characteristics/bluetooth_characteristics_model.dart';
import 'package:eeg_app/models/bluetooth_services/bluetooth_servicees_model.dart';
import 'package:eeg_app/models/processed_data_for_graph/processed_data_for_graph_model.dart';
import 'package:eeg_app/services/ble_service/ble_service.dart';
import 'package:eeg_app/services/eeg_ble_service/eeg_ble_service.dart';
import 'package:eeg_app/services/file_storage_service/file_storage_service.dart';
import 'package:eeg_app/services/share_content_service/share_content_service.dart';
import 'package:eeg_app/services/signal_processing_service/models/processed_channel_data/processed_channel_data.dart';
import 'package:eeg_app/services/signal_processing_service/models/wavesPowerRatio.dart';
import 'package:eeg_app/services/signal_processing_service/services/fast_fourier_transform/models/fast_fourier_transform_restult/fast_fourier_transform_result.dart';
import 'package:flutter/material.dart';
import 'package:flutter_blue_plus/flutter_blue_plus.dart';
import 'package:fluttertoast/fluttertoast.dart';

import 'enums/feeling_response.dart';


double _alphaBetaRatioWarningValue = 0.0;

double _thetaBetaRatioWarningValue = 0.0;


class MainViewModel extends ChangeNotifier {
  final EegBleService _eegBleService;
  final FileStorageService _fileStorageService;
  final ShareContentService _shareContentService;
  final ProcessedDataForGraphModel _processedDataForGraphModel;

  final BleService _bleService;

  final Marker _marker;
  final MarkerNotifier _markerNotifier;

  final BluetoothCharacteristicsModel _bluetoothCharacteristicsModel;
  final BluetoothServicesModel _bluetoothServicesModel;

  MainViewModel({
    required EegBleService eegBleService,
    required FileStorageService fileStorageService,
    required ShareContentService shareContentService,
    required ProcessedDataForGraphModel processedDataForGraphModel,
    required BleService bleService,
    required Marker marker,
    required MarkerNotifier markerNotifier,
    required BluetoothCharacteristicsModel bluetoothCharacteristicsModel,
    required BluetoothServicesModel bluetoothServicesModel,
  }) :
    _eegBleService = eegBleService,
    _fileStorageService = fileStorageService,
    _shareContentService = shareContentService,
    _processedDataForGraphModel = processedDataForGraphModel,
    _bleService = bleService,
    _marker = marker,
    _markerNotifier = markerNotifier,
    _bluetoothCharacteristicsModel = bluetoothCharacteristicsModel,
    _bluetoothServicesModel = bluetoothServicesModel;


  Stream<List<ScanResult>> get scanResults => _eegBleService.eegDevices;

  List<List<double>> get eegReadings =>
      _processedDataForGraphModel.processedDataForGraph.processedData
          .map((ProcessedChannelData processedChannelData) =>
              processedChannelData.eegReadings)
          .toList();

  List<List<double>> get bandPassFilterResults =>
      _processedDataForGraphModel.processedDataForGraph.processedData
          .map((ProcessedChannelData processedChannelData) =>
              processedChannelData.bandPassFilterResults)
          .toList();

  List<List<FFTDataPoint>> get fastFourierTransformResults =>
      _processedDataForGraphModel.processedDataForGraph.processedData
          .map((ProcessedChannelData processedChannelData) =>
              processedChannelData.fastFourierTransformResult)
          .toList();

  List<double> get alphaBetaRatio => _processedDataForGraphModel
      .listWavesPowerRatio.map((WavesPowerRatio wavesPowerRatio) =>
  wavesPowerRatio.alphaBetaRatio).toList();

  List<double> get thetaBetaRatio => _processedDataForGraphModel
      .listWavesPowerRatio.map((WavesPowerRatio wavesPowerRatio) =>
  wavesPowerRatio.thetaBetaRatio).toList();

  double get alphaBetaRatioWarningValue => _alphaBetaRatioWarningValue;

  double get thetaBetaRatioWarningValue => _thetaBetaRatioWarningValue;

  List<BluetoothCharacteristic> get bluetoothCharacteristic => _bluetoothCharacteristicsModel.bluetoothCharacteristics;

  List<BluetoothService> get bluetoothServices => _bluetoothServicesModel.bluetoothServices;

  int get markerType => _marker.markerType;

  void changeMarker(){
    try{
      _markerNotifier.changeMarker();
    } catch(e){
      Fluttertoast.showToast(msg: 'Error changing marker');
    }
  }

  Future<void> connectToDevice(ScanResult scanResult) async {
    // await _eegBleService.receiveMockData();
    BluetoothDevice eegDevice = await _eegBleService.connectToEegDevice(scanResult);
    BluetoothCharacteristic eegCharacteristic = await _eegBleService.getEegCharacteristic(eegDevice);
    await _eegBleService.startListeningAndProcessingCharacteristic(eegCharacteristic);
  }

  Future<void> disconnect() async{
    _bleService.disconnect();
  }

  Future<void> startScan() async {
    await _eegBleService.startScanForEegDevices();
  }

  Future<void> deleteSavedData() async{
    try {
      await _fileStorageService.deleteFileWithData();
      Fluttertoast.showToast(msg: 'Data deleted');
    } catch (e) {
      Fluttertoast.showToast(msg: 'Error deleting data');
    }
  }

  Future<void> sendSavedData() async {
    final file = await _fileStorageService.getFlushedFile();
    await _shareContentService.shareFile(file);
  }

  void changeWarningValues(FeelingResponse feelingResponse){

    List<WavesPowerRatio> lastWavesPowerRatio = _processedDataForGraphModel
        .listWavesPowerRatio
        .sublist(_processedDataForGraphModel.listWavesPowerRatio.length - 10);

    List<double> lastAlphaBetaRatio = lastWavesPowerRatio
        .map((WavesPowerRatio wavesPowerRatio) =>
    wavesPowerRatio.alphaBetaRatio).toList();

    List<double> lastThetaBetaRatio = lastWavesPowerRatio
        .map((WavesPowerRatio wavesPowerRatio) =>
    wavesPowerRatio.thetaBetaRatio).toList();

    double minAlphaBetaRatio = lastAlphaBetaRatio
        .reduce((currentMin, element) => currentMin < element
        ? currentMin : element);

    double maxThetaBetaRatio = lastThetaBetaRatio
        .reduce((currentMax, element) => currentMax > element
        ? currentMax : element);

    switch(feelingResponse){
      case FeelingResponse.good:
        if(minAlphaBetaRatio < _alphaBetaRatioWarningValue){
          _alphaBetaRatioWarningValue = minAlphaBetaRatio - 0.1;
        }
        if(maxThetaBetaRatio > _thetaBetaRatioWarningValue){
          _thetaBetaRatioWarningValue = maxThetaBetaRatio + 0.1;
        }
        break;
      case FeelingResponse.ok:

        break;
      case FeelingResponse.bad:
        if(minAlphaBetaRatio > _alphaBetaRatioWarningValue){
          _alphaBetaRatioWarningValue = minAlphaBetaRatio + 0.1;
        }
        if(maxThetaBetaRatio < _thetaBetaRatioWarningValue){
          _thetaBetaRatioWarningValue = maxThetaBetaRatio - 0.1;
        }
        break;
    }

  }

}