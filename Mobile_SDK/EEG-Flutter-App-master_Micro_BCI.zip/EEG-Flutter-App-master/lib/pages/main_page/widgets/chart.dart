import 'package:fl_chart/fl_chart.dart';
import 'package:flutter/material.dart';

class Chart extends StatelessWidget {
  final EdgeInsetsGeometry _padding;
  final List<FlSpot> _spots;
  final List<FlSpot> _secondSpots;

  const Chart({
    Key? key,
    EdgeInsetsGeometry padding = EdgeInsets.zero,
    required List<FlSpot> spots,
    List<FlSpot>? secondSpots,
  }) :
        _padding = padding,
        _spots = spots,
        _secondSpots = secondSpots ?? const [],
        super(key: key);

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: _padding,
      child: SizedBox(
        width: double.infinity,
        height: 100,
        child: LineChart(
          duration: const Duration(milliseconds: 0),
          LineChartData(
            lineBarsData: [
              LineChartBarData(
                dotData: const FlDotData(show: false),
                barWidth: 0.5,
                isCurved: true,
                spots: _spots,
              ),
              if (_secondSpots.isNotEmpty)
                LineChartBarData(
                  dotData: const FlDotData(show: false),
                  barWidth: 0.5,
                  isCurved: true,
                  color: Colors.red,
                  spots: _secondSpots,
                ),
            ],
            lineTouchData: const LineTouchData(enabled: false),
            gridData: const FlGridData(show: false),
            titlesData: const FlTitlesData(
              rightTitles: AxisTitles(sideTitles: SideTitles(showTitles: false)),
              topTitles: AxisTitles(sideTitles: SideTitles(showTitles: false)),
            ),
          ),
        ),
      ),
    );
  }
}
