import 'package:eeg_app/pages/main_page/main_providers.dart';
import 'package:eeg_app/pages/main_page/main_view_model.dart';
import 'package:eeg_app/pages/main_page/widgets/chart.dart';
import 'package:eeg_app/services/signal_processing_service/models/processed_channel_data/processed_channel_data.dart';
import 'package:eeg_app/services/signal_processing_service/services/fast_fourier_transform/models/fast_fourier_transform_restult/fast_fourier_transform_result.dart';
import 'package:fl_chart/fl_chart.dart';
import 'package:flutter/material.dart';
import 'package:flutter_blue_plus/flutter_blue_plus.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import 'enums/feeling_response.dart';

class MainView extends ConsumerWidget {
  const MainView({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final mainViewModel = ref.watch(mainViewModelProvider);
    // ref.watch(startScanProvider);
    return Scaffold(
      appBar: AppBar(
        title: const Text('EEG App'),
      ),
      body: SingleChildScrollView(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            SizedBox(
              height: 300,
              child: StreamBuilder<List<ScanResult>>(
                stream: mainViewModel.scanResults,
                builder: (context, snapshot) {
                  if(snapshot.hasData){
                    return ListView.builder(
                      shrinkWrap: true,
                      itemCount: snapshot.data!.length,
                      itemBuilder: (context, index) {
                        final scanResult = snapshot.data![index];
                        return ListTile(
                          title: Text(scanResult.device.localName),
                          subtitle: Text(scanResult.device.remoteId.str),
                          trailing: Text(scanResult.rssi.toString()),
                          onTap: () {
                            mainViewModel.connectToDevice(scanResult);
                          },
                        );
                      },
                    );
                  } else {
                    return const Text('No data');
                  }
                },
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(8.0),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: TextButton(
                      onPressed: () {
                        mainViewModel.startScan();
                      },
                      style: TextButton.styleFrom(
                        foregroundColor: Colors.white, backgroundColor: Colors.blue,
                      ),
                      child: const Text('Start scan'),
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: TextButton(
                      onPressed: () {
                        mainViewModel.disconnect();
                      },
                      style: TextButton.styleFrom(
                        foregroundColor: Colors.white, backgroundColor: Colors.blue,
                      ),
                      child: const Text('Disconnect'),
                    ),
                  ),
                ],
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(8.0),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: TextButton(
                      onPressed: () {
                        mainViewModel.deleteSavedData();
                      },
                      style: TextButton.styleFrom(
                        foregroundColor: Colors.white, backgroundColor: Colors.blue,
                      ),
                      child: const Text('Delete file'),
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: TextButton(
                      onPressed: () {
                        mainViewModel.sendSavedData();
                      },
                      style: TextButton.styleFrom(
                        foregroundColor: Colors.white, backgroundColor: Colors.blue,
                      ),
                      child: const Text('Send file'),
                    ),
                  ),
                ],
              ),
            ),
            Row(
              mainAxisAlignment:  MainAxisAlignment.spaceEvenly,
              children: [
                Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: TextButton(
                    onPressed: () {
                      mainViewModel.changeMarker();
                    },
                    style: TextButton.styleFrom(
                      foregroundColor: Colors.white, backgroundColor: Colors.blue,
                    ),
                    child: const Text('Change marker'),
                  ),
                ),
                Text('Marker: ${mainViewModel.markerType}'),
              ],
            ),
            // const Text('Raw Data:'),
            // const SizedBox(height: 10,),
            // Column(
            //   children: mainViewModel.eegReadings.map<Widget>((List<double> eegReadings) {
            //     return Column(
            //       crossAxisAlignment: CrossAxisAlignment.start,
            //       children: [
            //         Padding(
            //           padding: const EdgeInsets.only(left: 20),
            //           child: Text('Channel: ${mainViewModel.eegReadings.indexOf(eegReadings)}'),
            //         ),
            //         Chart(
            //           padding: const EdgeInsets.only(left: 5, right: 5, top: 15),
            //           spots: eegReadings
            //               .asMap()
            //               .entries
            //               .map((e) => FlSpot(e.key.toDouble(), e.value))
            //               .toList(),
            //         ),
            //       ],
            //     );
            //   }).toList(),
            // ),
            const Text('Band Pass Results:'),
            const SizedBox(height: 10,),
            Column(
              children: mainViewModel.bandPassFilterResults.map<Widget>((List<double> bandPassResult) {
                return Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Padding(
                      padding: const EdgeInsets.only(left: 20),
                      child: Text('Channel: ${mainViewModel.bandPassFilterResults.indexOf(bandPassResult)}'),
                    ),
                    Chart(
                      padding: const EdgeInsets.only(left: 5, right: 5, top: 15),
                      spots: bandPassResult
                          .asMap()
                          .entries
                          .map((e) => FlSpot(e.key.toDouble(), e.value))
                          .toList(),
                    ),
                  ],
                );
              }).toList(),
            ),
            // const Text('FFT Results:'),
            // Column(
            //   children: mainViewModel.fastFourierTransformResults.map<Widget>((List<FFTDataPoint> fftResult) {
            //     return Column(
            //       crossAxisAlignment: CrossAxisAlignment.start,
            //       children: [
            //         Padding(
            //           padding: const EdgeInsets.only(left: 20),
            //           child: Text('Channel: ${mainViewModel.fastFourierTransformResults.indexOf(fftResult)}'),
            //         ),
            //         Chart(
            //           padding: const EdgeInsets.only(left: 5, right: 5, top: 15),
            //           spots: fftResult
            //               .map((fftDataPoint) =>
            //               FlSpot(
            //                 fftDataPoint.frequency,
            //                 fftDataPoint.amplitude,
            //               )).toList(),
            //         ),
            //       ],
            //     );
            //   }).toList(),
            // ),

            const Text('Alpha/Beta:'),
            const SizedBox(height: 10,),
            Chart(
              padding: const EdgeInsets.only(left: 5, right: 5, top: 15),
              spots: mainViewModel.alphaBetaRatio
                  .asMap()
                  .entries
                  .map((e) => FlSpot(e.key.toDouble(), e.value))
                  .toList(),
              secondSpots: mainViewModel.alphaBetaRatioWarningValue != 0.0
                  ? mainViewModel.alphaBetaRatio
                  .asMap()
                  .entries
                  .map((e) => FlSpot(e.key.toDouble(), mainViewModel.alphaBetaRatioWarningValue))
                  .toList()
                  : null,
            ),

            const Text('Theta/Beta:'),
            const SizedBox(height: 10,),
            Chart(
              padding: const EdgeInsets.only(left: 5, right: 5, top: 15),
              spots: mainViewModel.thetaBetaRatio
                  .asMap()
                  .entries
                  .map((e) => FlSpot(e.key.toDouble(), e.value))
                  .toList(),
              secondSpots: mainViewModel.thetaBetaRatioWarningValue != 0.0
                  ? mainViewModel.thetaBetaRatio
                  .asMap()
                  .entries
                  .map((e) => FlSpot(e.key.toDouble(), mainViewModel.thetaBetaRatioWarningValue))
                  .toList()
                  : null,
            ),

            Padding(
                padding: const EdgeInsets.all(8.0),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    ElevatedButton(
                      onPressed: () {
                        mainViewModel.changeWarningValues(FeelingResponse.good);
                      },
                      child: const Text('Good'),
                    ),
                    const SizedBox(width: 10), // Spacing between buttons
                    ElevatedButton(
                      onPressed: () {
                        mainViewModel.changeWarningValues(FeelingResponse.ok);
                      },
                      child: const Text('Ok'),
                    ),
                    const SizedBox(width: 10), // Spacing between buttons
                    ElevatedButton(
                      onPressed: () {
                        mainViewModel.changeWarningValues(FeelingResponse.bad);
                      },
                      child: const Text('Bad'),
                    ),
                  ],
                ),
            ),

            Padding(
              padding: const EdgeInsets.all(8.0),
              child: Column(
                children: mainViewModel.bluetoothServices.map((service) {
                  return ListTile(
                    title: Text(service.uuid.toString()),
                  );
                }).toList(),
              ),
            ),
            const Text('Bluetooth Characteristic:'),
            Padding(
              padding: const EdgeInsets.all(8.0),
              child: Column(
                children: mainViewModel.bluetoothCharacteristic.map((characteristic) {
                  return ListTile(
                    title: Text(characteristic.uuid.toString()),
                  );
                }).toList(),
              ),
            ),
          ],
        ),
      ),
    );
  }
}