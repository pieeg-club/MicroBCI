import 'package:eeg_app/models/band_pass_results_for_graph/band_pass_results_for_graph_providers.dart';
import 'package:eeg_app/models/bluetooth_characteristics/bluetooth_characteristics_providers.dart';
import 'package:eeg_app/models/bluetooth_services/bluetooth_servicees_providers.dart';
import 'package:eeg_app/models/processed_data_for_graph/processed_data_for_graph_providers.dart';
import 'package:eeg_app/pages/main_page/main_view_model.dart';
import 'package:eeg_app/services/ble_service/ble_service_provider.dart';
import 'package:eeg_app/services/eeg_ble_service/eeg_ble_service_providers.dart';
import 'package:eeg_app/services/file_storage_service/file_storage_service_providers.dart';
import 'package:eeg_app/services/share_content_service/share_content_providers.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../services/file_storage_service/file_storage_service.dart';

final mainViewModelProvider = ChangeNotifierProvider<MainViewModel>((ref) {
  final eegBleService = ref.read(eegBleServiceProvider);
  final fileStorageService = ref.read(fileStorageServiceProvider);
  final shareContentService = ref.read(shareContentServiceProvider);

  final processedDataForGraphModel = ref.watch(processedDataForGraphModelNotifierProvider);

  final marker = ref.watch(markerProvider);
  final markerNotifier = ref.read(markerProvider.notifier);

  final bleService = ref.read(bleServiceProvider);

  final bluetoothCharacteristicsModel = ref.watch(bluetoothCharacteristicsModelNotifierProvider);
  final bluetoothServicesModel = ref.watch(bluetoothServicesModelNotifierProvider);

  return MainViewModel(
    eegBleService: eegBleService,
    fileStorageService: fileStorageService,
    shareContentService: shareContentService,
    processedDataForGraphModel: processedDataForGraphModel,

    bleService: bleService,

    marker: marker,
    markerNotifier: markerNotifier,

    bluetoothCharacteristicsModel: bluetoothCharacteristicsModel,
    bluetoothServicesModel: bluetoothServicesModel,
  );
});