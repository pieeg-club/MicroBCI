enum FeelingResponse{
  good,
  ok,
  bad,
}